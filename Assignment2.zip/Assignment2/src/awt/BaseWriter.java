//**********************************************//
//*SID: 1805246                                *//
//*Description: Base XML Writer, with XML file *//
//* Writer try-catch and instantiated          *//
//* instance fields                            *//
//**********************************************//
package awt;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;

public class BaseWriter 
{
	private DocumentBuilderFactory dbFactory;
	private DocumentBuilder dBuilder;
	private Document doc;
	
	public Document xmlConnection()
	{
		try
	    {
			// create the three layers for the XML writer
	        dbFactory = DocumentBuilderFactory.newInstance();
	        dBuilder = dbFactory.newDocumentBuilder();
	        doc = dBuilder.newDocument();
	    } 
		catch (Exception e) 
		{
			e.printStackTrace();
		}//end try...catch
		
		return doc;
		
	}

}


