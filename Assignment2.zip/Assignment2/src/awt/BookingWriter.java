//*************************************************//
//*SID: 1805246                                   *//
//*Description: Inherits from BaseWriter, and     *//
//* allows strings to be written to the Bookings  *//
//* XML file specifically.                        *//
//*************************************************//
package awt;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;

// Inherits from BaseWriter
public class BookingWriter extends BaseWriter
{
	private Element rootElement; 
	private Element theBooking;
	private Element theApartmentName;
	private Attr attr;
	private Element theFirstName; 
	private Element theLastName;
	private Element theMaxGuests;
	private Element theStartDate;
	private Element theEndDate;
	private Element theCatering;
	private TransformerFactory transformerFactory;
	private Transformer transformer;
	private DOMSource source;
	private StreamResult result;
	private  StreamResult consoleResult;
	private int BID = 101;
    	
	
	public void bookingWriter(Document doc, String filenameToWrite, String clientApartmentName, String clientFirstName, String clientLastName, String maxGuests,
			String bookingStartDate, String bookingEndDate, String bookingCatering)
	{
		try
		{
			// root element
	        rootElement = doc.createElement("clientsbookings");
	        doc.appendChild(rootElement);
			 
			// bookings element
	        theBooking = doc.createElement("clientbooking");
	        rootElement.appendChild(theBooking);
			
			// setting attribute to element
	        attr = doc.createAttribute("ID");
	        
	        // Randomise Booking ID to ensure security
	        BID = BID + 1;	        
	        attr.setValue(Integer.toString(BID));	        
	        JOptionPane.showMessageDialog(null, "Your booking ID is:  " + BID);
	        
	        theBooking.setAttributeNode(attr);
	       
	        // bookings element
	        theApartmentName = doc.createElement("apartmentname");
	        theApartmentName.appendChild(doc.createTextNode(clientApartmentName));
	        theBooking.appendChild(theApartmentName); 
			
			// bookings element
	        theFirstName = doc.createElement("firstname");
	        theFirstName.appendChild(doc.createTextNode(clientFirstName));
	        theBooking.appendChild(theFirstName); 
		 
			// bookings element
			theLastName = doc.createElement("lastname");
	        theLastName.appendChild(doc.createTextNode(clientLastName));
	        theBooking.appendChild(theLastName); 
			
			// bookings element
			theMaxGuests = doc.createElement("numberguests");
	        theMaxGuests.appendChild(doc.createTextNode(maxGuests));
	        theBooking.appendChild(theMaxGuests); 
			
			// bookings element
			theStartDate = doc.createElement("startdate");
	        theStartDate.appendChild(doc.createTextNode(bookingStartDate));
	        theBooking.appendChild(theStartDate); 
			
			// bookings element
			theEndDate = doc.createElement("enddate");
			theEndDate.appendChild(doc.createTextNode(bookingEndDate));
			theBooking.appendChild(theEndDate);
		
			// bookings element
			theCatering = doc.createElement("catering");
			theCatering.appendChild(doc.createTextNode(bookingCatering));
			theBooking.appendChild(theCatering);
	
			// Writes entered data to XML
	        transformerFactory = TransformerFactory.newInstance();
	        transformer = transformerFactory.newTransformer();
			
	        source = new DOMSource(doc);
	       
			result = new StreamResult(new File(filenameToWrite));
	        transformer.transform(source, result);
	
			// Testing statement printed to console
	        consoleResult = new StreamResult(System.out);
	        transformer.transform(source, consoleResult);
		}
        catch (Exception e) 
		{
			e.printStackTrace();
		}//end try...catch
		
	}

}




