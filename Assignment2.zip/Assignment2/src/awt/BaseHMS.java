//**********************************************//
//*SID: 1805246                                *//
//*Description: Base HMS file, with Login      *//
//*And GUI components included.                *//
//**********************************************//
package awt;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class BaseHMS extends JFrame implements ActionListener
{
	private final FlowLayout myFlowLayout1;
	private final BorderLayout myBorderLayout2;
	private final FlowLayout myFlowLayout3;
	private final FlowLayout myFlowLayout4;
	private final BorderLayout myBorderLayout3;
	private final BorderLayout myBorderLayout3B;
    private BorderLayout myBorderLayout_booking1; // first booking panel
    private FlowLayout myFlowLayout_booking1;  // booking frame
    private BorderLayout myBorderLayout_booking2; //  apartments panel (second booking panel)
    private BorderLayout myBorderLayout_booking3; //  booking selections panel (third booking panel), split into labels and text fields
    private FlowLayout myFlowLayout_booking3; // Also booking selections panel (third booking panel)
    private BorderLayout myBorderLayout_booking3A;
    private BorderLayout myBorderLayout_booking3B;
    
	private final JPanel myPanel1;
	private final JPanel myPanel2;
	private final JPanel myPanel2B;
	private final JPanel myPanel3;
	
	private JPanel myPanel_booking1;
	private JPanel myPanel_booking3;
	private JPanel myPanel_booking3A;
	private JPanel myPanel_booking3B;
	private JPanel myPanel_booking2; 
		
		
	private JLabel myAptSelectionLabel;
	private JLabel myFirstNameLabel;
	private JLabel myLastNameLabel;
	private JLabel myMaxGuestsLabel;
	private JLabel myCateringBookingLabel;
	private JLabel myStartDateLabel;
	private JLabel myEndDateLabel;
	
	private JTextField myAptSelectionTextField;
	private JTextField myFirstNameTextField;
	private JTextField myLastNameTextField;	 
	private JTextField myMaxGuestsTextField;
	private JTextField myCateringBookingTextField;
	private JTextField myStartDateTextField;
	private JTextField myEndDateTextField;
  
	private final JLabel myLoginLabel;
	private final JLabel myUsernameLabel;
	private final JLabel myPasswordLabel;
	
	//Client Option JLabel
	private JLabel clientMenuOptionsLabel;
	// Client Option JTextField
	private JTextField clientMenuOptionsTextField;
	
	// Client Menu Options' javax.swing.Font 
	private Font aClientFont;
	private Font aManagerFont;
	
	//Manager Option JLabel
	private JLabel managerMenuOptionsLabel;
	//Manager Options JLabel
	private JTextField managerMenuOptionsTextField;
	
	
	private final JTextField myLoginTextField;
	private final JTextField myUsernameTextField;
	private final JTextField myPasswordTextField;
	private String myLoginOptionNumber = "";
	private String myClientMenuOptionNumber = "";
	private String myManagerMenuOptionNumber = "";
	private String myUsernameText = "";
	private String myPasswordText = "";
	
	private boolean login = false;
	private int loginCounter = 0;
	private boolean clientMenuDisplayed = false;
	private boolean ManagerMenuDisplayed = false;
	private boolean clientBookingWriteReady = false;
	
	
	// Client Login Details
	private String[][] clientCredentials = {{"Client01", "Client01Pass"}};
	private String tempClientUsername = "";
	private String tempClientPassword = "";
	
	// Manager Login Details, with a more secure password
	private String[][] managerCredentials = {{"Manager01", "z36N4g"}};
	private String tempManagerUsername = "";
	private String tempManagerPassword = "";
	
	
	private JFrame myBookingFrame;
	
	private BungalowReader myBungalowsReader;
	
	private String[][] myBungalowsData = new String[10][9];
	private String column[]={"Apartment ID","Apartment Name", "Price per Night","Start Date", "End Date", "Max Guests", "Number Beds", "Number Baths", "Living Room"};  
	
	private JPanel myDisplayPanel;
	private JFrame myDisplayFrame;
	private JScrollPane myDisplayScrollPanel;
	
	private Document writeDoc;
	private BookingWriter myXMLBookingWriter;
	
	private String aClientBookingAptName = "";
	private String aClientBookingFirstName = "";
	private String aClientBookingLastName = "";
	private String aClientBookingMaxGuests = "";
	private String aClientBookingStartDate = "";
	private String aClientBookingEndDate = "";
	private String aClientBookingCatering = "";
	
	private File inputFile;
	private DocumentBuilder dBuilder;
	private DocumentBuilderFactory dbFactory;
	private Document aBookingDoc;	
	
	private JButton myBookingButton;
	//=======================================================================================================================================================//
	
	
	
	//no-argument constructor
  	public BaseHMS()
  	{
  		super("Hotel Management System (HMS) for Unnamed Hotel Company");
  		myFlowLayout1 = new FlowLayout();
  		myBorderLayout2 = new BorderLayout();
  		myBorderLayout2.setHgap(10);
  		myBorderLayout2.setVgap(10);
  		myFlowLayout3 = new FlowLayout();
  		myFlowLayout4 = new FlowLayout();
  		myBorderLayout3 = new BorderLayout();
  		myBorderLayout3B = new BorderLayout();
            	  
  		myLoginLabel = new JLabel("Login By Entering (1: Client, 2: Manager)");
  		myLoginTextField = new JTextField(50);
  		myLoginTextField.addActionListener(this);

            	  
  		setLayout(myFlowLayout1);        
                  
  		myPanel1 = new JPanel();
  		myPanel2 = new JPanel();
  		myPanel2B = new JPanel();
  		myPanel3 = new JPanel();
  		
                  
  		myPanel1.setLayout(myBorderLayout2);    
  		myPanel1.setVisible(true);
  		this.add(myPanel1);    
  		myPanel2.setLayout(myBorderLayout3);    
  		myPanel2.setVisible(true);
  		myPanel2B.setLayout(myBorderLayout3B);
  		myPanel2B.setVisible(true);
  		myPanel1.add(myPanel2, BorderLayout.EAST);
  		this.add(myPanel1);   
  		myPanel1.add(myPanel2B, BorderLayout.WEST);
  		this.add(myPanel1);
                  
  		myPanel3.setLayout(myFlowLayout4);
  		myPanel3.setVisible(true);
  		myPanel1.add(myPanel3, BorderLayout.SOUTH);                  
  		this.add(myPanel1);   
                  
  		myLoginLabel.setVisible(true);
  		myPanel2B.add(myLoginLabel, BorderLayout.NORTH);
  		myPanel2B.setVisible(true);
  		myPanel1.add(myPanel2B, BorderLayout.WEST);
  		this.add(myPanel1);
                  
                  
  		myLoginTextField.setSize(100, 100);
  		myLoginTextField.setVisible(true);
  		myPanel2.add(myLoginTextField, BorderLayout.NORTH);
  		myPanel2.setVisible(true);
  		myPanel1.add(myPanel2, BorderLayout.EAST);
  		this.add(myPanel1);
                  
     
  		myUsernameLabel = new JLabel("Username:  ");
  		myUsernameTextField = new JTextField(50);
  		myUsernameTextField.addActionListener(this);

  		myUsernameLabel.setVisible(true);
  		myPanel2B.add(myUsernameLabel, BorderLayout.CENTER);
        myPanel2B.setVisible(true);
        myPanel1.add(myPanel2B, BorderLayout.WEST);
        this.add(myPanel1);
                  
        myUsernameTextField.setSize(100, 100);
        myUsernameTextField.setVisible(true);
        myPanel2.add(myUsernameTextField, BorderLayout.CENTER);
        myPanel2.setVisible(true);
        myPanel1.add(myPanel2, BorderLayout.EAST);
        this.add(myPanel1);
                  
                  
        myPasswordLabel = new JLabel("Password:  ");
        myPasswordTextField = new JTextField(50);
        myPasswordTextField.addActionListener(this);
                  
        myPasswordLabel.setVisible(true);
        myPanel2B.add(myPasswordLabel, BorderLayout.SOUTH);
        myPanel2B.setVisible(true);
        myPanel1.add(myPanel2B, BorderLayout.WEST);
        this.add(myPanel1);
                  
        myPasswordTextField.setSize(100, 100);
        myPasswordTextField.setVisible(true);
        myPanel2.add(myPasswordTextField, BorderLayout.SOUTH);
        myPanel2.setVisible(true);
        myPanel1.add(myPanel2, BorderLayout.EAST);
        this.add(myPanel1);
    
        
        myAptSelectionLabel = new JLabel("Apartment Name");
  		myAptSelectionTextField = new JTextField(15);
  		myAptSelectionTextField.addActionListener(this);
  		
  		myFirstNameLabel = new JLabel("First Name");
   		myFirstNameTextField = new JTextField(15);
   		myFirstNameTextField.addActionListener(this);
   		
   		myLastNameLabel = new JLabel("Last  Name");
   		myLastNameTextField = new JTextField(15);
   		myLastNameTextField.addActionListener(this);
   		
   		myMaxGuestsLabel = new JLabel("Max Guests");
   		myMaxGuestsTextField = new JTextField(15);
   		myMaxGuestsTextField.addActionListener(this);
   		
   		myStartDateLabel = new JLabel("Start Date");
   		myStartDateTextField = new JTextField(15);
   		myStartDateTextField.addActionListener(this);
   		
   		myEndDateLabel = new JLabel("End Date");
   		myEndDateTextField = new JTextField(15);
   		myEndDateTextField.addActionListener(this);
   		
   		myCateringBookingLabel = new JLabel("Catering(Yes or No)");
   		myCateringBookingTextField = new JTextField(15);
   		myCateringBookingTextField.addActionListener(this);           
   		
   		myDisplayFrame = new JFrame();
   		myDisplayPanel = new JPanel();         
  	}
    

  
    public void actionPerformed(ActionEvent event)
    {
    	
    	myLoginOptionNumber = myLoginTextField.getText();
    	
    	// Debugging statement
    	System.out.println(myLoginOptionNumber);
    	
    	myUsernameText = myUsernameTextField.getText();
    	
    	// Debugging statement
    	System.out.println(myUsernameText);
    	
    	myPasswordText = myPasswordTextField.getText();
    	// Debugging statement
    	System.out.println(myPasswordText);
    	
    	// Read the Client Menu Option
		while (login == false)
		{
			for(int i = 0; i<2; i++)
	    	{
				tempClientUsername = clientCredentials[i][0];
				tempClientPassword = clientCredentials[i][1];
				
				tempManagerUsername = managerCredentials[i][0];
				tempManagerPassword = managerCredentials[i][1];
				
				
				// Debugging statement
				System.out.println("Game ON is:  " + tempClientUsername);
				if ((new String(myUsernameText).equals(tempClientUsername)) & new String(myPasswordText).equals(tempClientPassword) & new String(myLoginOptionNumber).equals("1"))
				{
					System.out.println("Client Login Successful!");
					JOptionPane.showMessageDialog(null,"Client Login Successfull");
					login = true;
						
					// Display the Client Options menu
	    			// PANEL 3 --> Client Options Menu
	    			StringBuilder buff = new StringBuilder();
			        buff.append("<html><table>");
			        buff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "CLIENT OPTIONS"));                     
			        buff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "1. Do Your Booking"));
			        buff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "2. Manage Your Booking"));
			        buff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "3. EXIT"));
			        buff.append("</table></html>");
	             
			        aClientFont = new Font("Arial", Font.ITALIC, 24);
			       			            
			        clientMenuOptionsLabel= new JLabel(buff.toString());    
			        clientMenuOptionsLabel.setFont(aClientFont);
			        myPanel3.add(clientMenuOptionsLabel, BorderLayout.NORTH);
			  		myPanel3.setVisible(true);
			  		myPanel1.add(myPanel3, BorderLayout.SOUTH);
			  		myPanel1.revalidate();
			  		myPanel1.repaint();
			  		this.add(myPanel1);
			  		
			  		clientMenuOptionsTextField = new JTextField(50);
			    	clientMenuOptionsTextField.addActionListener(this);
			    	myPanel3.add(clientMenuOptionsTextField, BorderLayout.SOUTH);
			  		myPanel3.setVisible(true);
			        myPanel1.add(myPanel3, BorderLayout.SOUTH);
			        myPanel1.revalidate();
			      	myPanel1.repaint();
			        this.add(myPanel1);			        
			        
			        clientMenuDisplayed = true;
			        
				}//end if
				else if ((new String(myUsernameText).equals(tempManagerUsername)) & new String(myPasswordText).equals(tempManagerPassword) & new String(myLoginOptionNumber).equals("2"))
				{
					System.out.println("Manager Login Successful!");
					JOptionPane.showMessageDialog(null,"Manager Login Successfull");
					login = true;
					loginCounter = 3;
	
	
					// Display the Client Options menu
	    			// PANEL 3 --> Client Options Menu
	    			StringBuilder managerBuff = new StringBuilder();
	    			managerBuff.append("<html><table>");
	    			managerBuff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "MANAGER OPTIONS"));                     
	    			managerBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "1. View ALL Bookings"));
	    			managerBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "2. Manage a Booking"));
	    			managerBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "3. EXIT"));
	    			managerBuff.append("</table></html>");
	             
			        aManagerFont = new Font("Arial", Font.ITALIC, 24);
			       			            
			        managerMenuOptionsLabel= new JLabel(managerBuff.toString());    
			        managerMenuOptionsLabel.setFont(aManagerFont);
			        myPanel3.add(managerMenuOptionsLabel, BorderLayout.NORTH);
			  		myPanel3.setVisible(true);
			  		myPanel1.add(myPanel3, BorderLayout.SOUTH);
			  		myPanel1.revalidate();
			  		myPanel1.repaint();
			  		this.add(myPanel1);
			  		
			  		managerMenuOptionsTextField = new JTextField(50);
			    	managerMenuOptionsTextField.addActionListener(this);
			    	myPanel3.add(managerMenuOptionsTextField, BorderLayout.SOUTH);
			  		myPanel3.setVisible(true);
			        myPanel1.add(myPanel3, BorderLayout.SOUTH);
			        myPanel1.revalidate();
			      	myPanel1.repaint();
			        this.add(myPanel1);			        
				}//end else if
				else
		        {
					if ((loginCounter==0) & (login==false))
					{
						loginCounter = loginCounter + 1;
						JOptionPane.showMessageDialog(this, "Login Failed!");												
					}
		        	
		        }//end else
	    	}//end for
		}//end while
		
		if(clientMenuDisplayed==true)
		{
			if (new String(clientMenuOptionsTextField.getText()).equals("1"))
			{
				// Debugging statement
				System.out.println("Debug Check");
	      		
	      		myBungalowsReader = new BungalowReader();
	      		myXMLBookingWriter  = new BookingWriter();
	      		
	      		myBungalowsData = myBungalowsReader.bungalowReader();
	      		
     
	      		// Implement new frame for the Booking
				myBookingFrame = new JFrame("Do Booking");	
				myBookingFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				myBookingFrame.setSize(1200, 500);
				myBookingFrame.setVisible(true);
						
				// Displays Booking Options
				myFlowLayout_booking1 = new FlowLayout(); // Booking JFrame
				myBorderLayout_booking1 = new BorderLayout(); // First booking panel
				myBorderLayout_booking2 = new BorderLayout(); // Second booking panel to view apartments
				myBorderLayout_booking3 = new BorderLayout(); // Third booking panel for selecting Booking
				myFlowLayout_booking3 = new FlowLayout(); // Third booking panel for selecting Booking
		  				      
		  		myBookingFrame.setLayout(myFlowLayout_booking1);        
		                  
		  		myPanel_booking1 = new JPanel();
		  		myPanel_booking3 = new JPanel();
		  		myPanel_booking3A = new JPanel();
		  		myPanel_booking3B = new JPanel();
		  		myPanel_booking2 = new JPanel();
		  		
		                  
		  		myPanel_booking1.setLayout(myBorderLayout_booking1);
		  		myBookingFrame.add(myPanel_booking1);
		  		
		  		myPanel_booking2.setLayout(myBorderLayout_booking2);    
		  		myPanel_booking2.setVisible(true);
		  		myPanel_booking1.add(myPanel_booking2, BorderLayout.NORTH);    
		  		myBookingFrame.add(myPanel_booking1);
		  		
		  		myPanel_booking3.setLayout(myFlowLayout_booking3);    
		  		myFlowLayout_booking3.setAlignment(FlowLayout.CENTER);
		  		myPanel_booking3.setVisible(true);
		  		myPanel_booking1.add(myPanel_booking3, BorderLayout.SOUTH);
		  		myBookingFrame.add(myPanel_booking1);
		  				  		
		  		myBungalowsReader.tableDisplay(myBungalowsData, column, myPanel_booking2, myBookingFrame);
		  		
		  		
		  		clientBookingWriteReady = true;  		
		  		
			}
	      		
	    }
		
		if (clientBookingWriteReady==true)
		{
			
			// Apartment Selection
	  		myAptSelectionLabel.setVisible(true);
	  		myPanel_booking3.add(myAptSelectionLabel, BorderLayout.NORTH);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH); 
	  		myBookingFrame.add(myPanel_booking1);	    			                  
	                  
	  		myAptSelectionTextField.setSize(15, 15);
	  		myAptSelectionTextField.setVisible(true);
	  		myPanel_booking3.add(myAptSelectionTextField, BorderLayout.CENTER);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
	  		myBookingFrame.add(myPanel_booking1);
	  		
	  		// First Name for booking Selection
	  		myFirstNameLabel.setVisible(true);
	  		myPanel_booking3.add(myFirstNameLabel);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH); 
	  		myBookingFrame.add(myPanel_booking1);	    			                  
	                  
	  		myFirstNameTextField.setSize(20, 15);
	  		myFirstNameTextField.setVisible(true);
	  		myPanel_booking3.add(myFirstNameTextField);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
	  		myBookingFrame.add(myPanel_booking1);
	  		
	  		// Last Name for booking Selection
	  		myLastNameLabel.setVisible(true);
	  		myPanel_booking3.add(myLastNameLabel);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH); 
	  		myBookingFrame.add(myPanel_booking1);	    			                  
	                  
	  		myLastNameTextField.setSize(15, 15);
	  		myLastNameTextField.setVisible(true);
	  		myPanel_booking3.add(myLastNameTextField);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
	  		myBookingFrame.add(myPanel_booking1);
	  			    			  		
	  		// Max Guests for booking Selection
	  		myMaxGuestsLabel.setVisible(true);
	  		myPanel_booking3.add(myMaxGuestsLabel);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH); 
	  		myBookingFrame.add(myPanel_booking1);	    			                  
	                  
	  		myMaxGuestsTextField.setSize(15, 15);
	  		myMaxGuestsTextField.setVisible(true);
	  		myPanel_booking3.add(myMaxGuestsTextField);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
	  		myBookingFrame.add(myPanel_booking1);
	  		
	  		// Start Date for booking Selection
	  		myStartDateLabel.setVisible(true);
	  		myPanel_booking3.add(myStartDateLabel);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH); 
	  		myBookingFrame.add(myPanel_booking1);	    			                  
	                  
	  		myStartDateTextField.setSize(15, 15);
	  		myStartDateTextField.setVisible(true);
	  		myPanel_booking3.add(myStartDateTextField);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
	  		myBookingFrame.add(myPanel_booking1);
	  		
	  		// End Date for booking Selection
	  		myEndDateLabel.setVisible(true);
	  		myPanel_booking3.add(myEndDateLabel);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH); 
	  		myBookingFrame.add(myPanel_booking1);	    			                  
	                  
	  		myEndDateTextField.setSize(20, 15);
	  		myEndDateTextField.setVisible(true);
	  		myPanel_booking3.add(myEndDateTextField);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
	  		myBookingFrame.add(myPanel_booking1);
	  		
	  		// Catering option for booking Selection
	  		myCateringBookingLabel.setVisible(true);
	  		myPanel_booking3.add(myCateringBookingLabel);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH); 
	  		myBookingFrame.add(myPanel_booking1);	    			                  
	                  
	  		myCateringBookingTextField.setSize(15, 15);
	  		myCateringBookingTextField.setVisible(true);
	  		myPanel_booking3.add(myCateringBookingTextField);
	  		myPanel_booking3.setVisible(true);
	  		myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
	  		myBookingFrame.add(myPanel_booking1);
	  		
		
	  		myBookingButton = new JButton("Booking");
	  		myBookingButton.addActionListener(this);
	  		myBookingButton.setActionCommand("booking");
	  		myBookingButton.setVisible(true);
		  	myPanel_booking3.add(myBookingButton);
		  	myPanel_booking3.setVisible(true);
		  	myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
		  	myBookingFrame.add(myPanel_booking1);
		  		
		  	

	  		if ("booking".equals(event.getActionCommand())) 
	  		{
				aClientBookingAptName = myAptSelectionTextField.getText();
		  		aClientBookingFirstName = myFirstNameTextField.getText();
		  		aClientBookingLastName = myLastNameTextField.getText();
		  		aClientBookingMaxGuests = myMaxGuestsTextField.getText();
		  		aClientBookingStartDate = myStartDateTextField.getText();
		  		aClientBookingEndDate = myEndDateTextField.getText();
		  		aClientBookingCatering = myCateringBookingTextField.getText();
		  		
		  		writeDoc = myXMLBookingWriter.xmlConnection();

		  		myXMLBookingWriter.bookingWriter(writeDoc, "H:\\eclipse\\workspace\\XML\\Bookings.xml", 
		  				aClientBookingAptName, aClientBookingFirstName, aClientBookingLastName, aClientBookingMaxGuests, aClientBookingStartDate, aClientBookingEndDate, aClientBookingCatering);
		  		    				
	  		}
	  
		}
		
		
    }//end method
			
}//end class
    				
	