//**********************************************//
//*SID: 1805246                                *//
//*Description: Base XML Reader, with XML file *//
//* Reader try-catch and a blank TableDisplay  *//
//* For other classes to inherit.              *//
//**********************************************//
package awt;

import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public abstract class BaseReader
{
	private File inputFile;
	private DocumentBuilder dBuilder;
	private DocumentBuilderFactory dbFactory;
	private Document doc;
	
	// Try-catch for reading an XML file
	public Document xmlConnection(String filename)
	{

		try {

			inputFile = new File(filename);
			dbFactory = DocumentBuilderFactory.newInstance();
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
						
		} catch (Exception e) {
			e.printStackTrace();
			
		}//end try...catch
		return doc;
		
	}// end method
			
	// Method for Bungalow Reader to inherit
	abstract void tableDisplay(String[][] aDataTable, String aColumn[], JPanel displayPanel, JFrame displayFrame);

}