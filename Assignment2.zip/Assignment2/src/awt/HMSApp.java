//*************************************************//
//*SID: 1805246                                   *//
//*Description: The main class for the application*//
//* which runs the hotel management system        *//
//*************************************************//


package awt;


import javax.swing.JFrame;

public class HMSApp
{
	private static BaseHMS myHMS;
        public static void main(String[] args)
            {
              myHMS = new BaseHMS();
              myHMS.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          	 myHMS.setSize(1200, 400);
          	 myHMS.setVisible(true);
            }

}//end class