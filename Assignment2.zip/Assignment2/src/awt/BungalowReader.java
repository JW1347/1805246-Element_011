//*************************************************//
//*SID: 1805246                                   *//
//*Description: Inherits from BaseReader, and     *//
//* allows strings to be Read from the Bungalows  *//
//* XML file specifically.                        *//
//*************************************************//

package awt;

import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import javax.swing.*;
import java.awt.*;


// Inherits methods from BaseReader
public class BungalowReader extends BaseReader
{
	private Document aDoc;
	private String[][] data = new String[10][9];	
	private int rowCounter = 0;
	private int columnCounter = 0;
	
	private JTable bungalowTable;   
	private JScrollPane displayScrollPanel;
	
	// Method to view data from XML
	public String[][] bungalowReader()
	{

		// Designates the local directory of the XML file
		// Might need changing for other systems
		aDoc = xmlConnection("H:\\eclipse\\workspace\\XML\\Apartments.xml");
		System.out.println("Root element :" + aDoc.getDocumentElement().getNodeName());
		NodeList nList = aDoc.getElementsByTagName("apartment");
		System.out.println("----------------------------");
		
		for (int temp = 0; temp < nList.getLength(); temp++)
		{
			Node nNode = nList.item(temp);
			System.out.println("\nCurrent Element :" + nNode.getNodeName());
			
			if (nNode.getNodeType() == Node.ELEMENT_NODE) 
			{
				Element eElement = (Element) nNode;
				String aptID_Table = eElement.getAttribute("ID");
				String aptName_Table = eElement.getElementsByTagName("apartmentname").item(0).getTextContent();
				String price_Table = eElement.getElementsByTagName("price").item(0).getTextContent();
				String startDate_Table = eElement.getElementsByTagName("startdate").item(0).getTextContent();
				String endDate_Table = eElement.getElementsByTagName("enddate").item(0).getTextContent();
				String maxGuests_Table = eElement.getElementsByTagName("maxguests").item(0).getTextContent();
				String numBeds_Table = eElement.getElementsByTagName("numberbeds").item(0).getTextContent();
				String numBaths_Table = eElement.getElementsByTagName("numberbeds").item(0).getTextContent();
				String livingRoom_Table = eElement.getElementsByTagName("livingroom").item(0).getTextContent();
				
				data[rowCounter][columnCounter] = aptName_Table;
				columnCounter = columnCounter + 1;
				
				data[rowCounter][columnCounter] = aptID_Table;
				columnCounter = columnCounter + 1;
				
				data[rowCounter][columnCounter] = price_Table;
				columnCounter = columnCounter + 1;
				
				data[rowCounter][columnCounter]  = startDate_Table;
				columnCounter = columnCounter + 1;
				
				data[rowCounter][columnCounter] = endDate_Table;
				columnCounter = columnCounter + 1;
				
				data[rowCounter][columnCounter]  = maxGuests_Table;
				columnCounter = columnCounter + 1;
				
				data[rowCounter][columnCounter] = numBeds_Table;
				columnCounter = columnCounter + 1;
				
				data[rowCounter][columnCounter] = numBaths_Table;
				columnCounter = columnCounter + 1;
				
				data[rowCounter][columnCounter] = livingRoom_Table;
				
				// Debugging statements				
				System.out.println("Apartment ID: " +  aptID_Table);
				System.out.println("Price per Night : " + price_Table);				
			    System.out.println("Start Date: " + startDate_Table);
				System.out.println("End Date: " + endDate_Table);
				System.out.println("Max number of guests: " + maxGuests_Table);
				System.out.println("Number of Bedrooms: " + numBeds_Table);
				System.out.println("Number of Bathrooms: " + numBaths_Table);
				System.out.println("Separate Living Room: " + livingRoom_Table);
			}// end if
			
			rowCounter = rowCounter + 1;
			columnCounter = 0;
		}// end for
		return data;
	}
	
	// Inherited method from BaseReader, overridden
	public void tableDisplay(String[][] dataTable, String columnTable[], JPanel displayPanel, JFrame displayFrame)
	{
			bungalowTable = new JTable(dataTable,columnTable);    
			bungalowTable.setBounds(30,40,1200,200);
			displayScrollPanel = new JScrollPane(bungalowTable);
			
		 	displayPanel.add(displayScrollPanel);
		    
		    displayFrame.add(displayPanel);             
		    displayFrame.setVisible(true);   
	}
		
	
}